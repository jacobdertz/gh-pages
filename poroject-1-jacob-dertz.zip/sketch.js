
function setup() {
createCanvas(400, 400);
}
function draw() {
background(204);
rect(100, 200, 40, 200);
rect(100, 100, 40, 100);
rect(100, 150, 40, 150);
rect(100, 50, 40, 50);
rect(100, 200, 10, 200);
  rect(130, 200, 10, 200);

  rect(20, 200, 10, 200);
  ellipse(25,375,50,50)
ellipse(25,350,50,50)
  ellipse(25,325,50,50)
  ellipse(25,300,50,50)
  ellipse(25,275,50,50)
  ellipse(25,275,50,50)
rect(20, 200, 10, 25);
  
  
triangle(200, 54, 175, 400, 250, 400);
  triangle(200, 54, 175, 400, 250, 400);
  rect(185, 200, 40, 10);
  
rect(300, 200, 80, 200);
rect(320, 200, 40, 250);
rect(320, 200, 40, 10);

  
}
