function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(220);
  ellipseMode(CORNER); 
 
ellipse(mouseX, mouseY,50, 50, 100, 100);
ellipseMode(CORNERS);
fill(100); 
ellipse(mouseX, mouseY,25, 25, 50, 50); 
  if(mouseIsPressed){
  fill(0);
}else{
 fill(255); 
} 
  rect(100, 40, 200, 80)
function draw() {
   if (keyIsPressed === true) {
    fill(255);
  } else {
    fill(0);
  }
  rect(100, 40, 200, 80)
}
}
