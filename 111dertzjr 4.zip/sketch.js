function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(0);
  strokeWieght(4);
  stroke(255);
}
var x = 0;
while(x<width){
  ellipse(x, 200, 25, 25)
  x = x +50;
}
va
function mousePressed() {
  if (value === 0) {
    value = 255;
  } else {
    value = 0;
  }
}
function draw() {
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(25, 100, 100, 100);
}

